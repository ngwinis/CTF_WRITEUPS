// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.13;

import { Create2 } from "openzeppelin-contracts/contracts/utils/Create2.sol";
import { DiceMarket } from "./DiceMarket.sol";
import { DiceMarketDAO, DiceMarketHolder, IProposalTarget, IProposalVerifier, ITallyVerifier, IVoteVerifier } from "./DiceMarketDAO.sol";
import { ProposalVerifier } from "../circuits/generated/ProposalVerifier.sol";
import { TallyVerifier } from "../circuits/generated/TallyVerifier.sol";
import { VoteVerifier } from "../circuits/generated/VoteVerifier.sol";

contract CreateMarketProposal is DiceMarketHolder, IProposalTarget {
    function executeProposal() external override {
        market.createMarket("Will crypto/the-2000s-american-housing-crisis have more than zero solves?");
    }

    function cleanup() external {
        selfdestruct(payable(0));
    }
}

contract Setup {
    DiceMarketDAO public dao;
    DiceMarket public market;

    constructor(
        uint256[2] memory tallyPubKey,
        uint256 voterId,
        bytes32 proposalSalt,
        uint256 proposalNullifierHash,
        DiceMarketDAO.Proof memory proposalProof,
        uint256 voteNullifier,
        uint256[4] memory vote,
        DiceMarketDAO.Proof memory voteProof,
        DiceMarketDAO.Proof memory tallyProof
    ) payable {
        address createMarketProposal = Create2.deploy(0, proposalSalt, type(CreateMarketProposal).creationCode);
        dao = new DiceMarketDAO{value: 1 ether}(
            IProposalVerifier(address(new ProposalVerifier())),
            IVoteVerifier(address(new VoteVerifier())),
            ITallyVerifier(address(new TallyVerifier())),
            tallyPubKey[0],
            tallyPubKey[1]
        );
        market = dao.market();
        dao.registerVoter(voterId);
        uint256 proposalIndex = dao.propose(IProposalTarget(createMarketProposal), proposalNullifierHash, proposalProof);
        dao.vote(proposalIndex, voteNullifier, vote[0], vote[1], vote[2], vote[3], voteProof);
        dao.finalizeProposal(proposalIndex, 1, tallyProof);
        CreateMarketProposal(createMarketProposal).cleanup();

        assert(address(market).balance == 1 ether);
        assert(bytes(market.markets(0)).length == 73);
        assert(market.marketResolution(0) == 0);
    }

    function isSolved() external view returns (bool) {
      return address(market).balance == 0;
    }

}
