// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.13;

struct Vote {
    address voter;
    uint256 bet;
}

contract DiceMarket {
    address public owner;
    uint256 nextMarketIndex;

    mapping(uint256 => string) public markets;
    mapping(uint256 => uint8) public marketResolution;
    mapping(uint256 => mapping(address => bool)) votes;
    mapping(uint256 => Vote[]) noVotes;
    mapping(uint256 => Vote[]) yesVotes;
    mapping(uint256 => uint256) public totalNoBet;
    mapping(uint256 => uint256) public totalYesBet;
    mapping(uint256 => mapping(address => bool)) cashedOut;

    constructor() payable {
        owner = msg.sender;
    }

    modifier onlyOwner {
        require(msg.sender == owner);
        _;
    }

    function createMarket(string calldata name) external onlyOwner {
        markets[nextMarketIndex] = name;
        marketResolution[nextMarketIndex] = 0;
        nextMarketIndex += 1;
    }

    function bet(uint256 market, bool vote) external payable {
        require(msg.value != 0, "put some skin in the game");
        require(marketResolution[market] == 0);
        votes[market][msg.sender] = vote;
        if (!vote) {
            noVotes[market].push(Vote(msg.sender, msg.value));
            totalNoBet[market] += msg.value;
        } else {
            yesVotes[market].push(Vote(msg.sender, msg.value));
            totalYesBet[market] += msg.value;
        }
    }

    function resolveMarket(uint256 market, bool resolution) external onlyOwner {
        require(marketResolution[market] == 0);
        marketResolution[market] = resolution ? 2 : 1;
    }

    function cashout(uint256 market) external {
        require(marketResolution[market] == (votes[market][msg.sender] ? 2 : 1));
        require(!cashedOut[market][msg.sender]);
        cashedOut[market][msg.sender] = true;
        if (marketResolution[market] == 1) {
            for (uint256 i = 0; i < noVotes[market].length; i++) {
                if (noVotes[market][i].voter == msg.sender) {
                    uint256 payout = noVotes[market][i].bet + (noVotes[market][i].bet * totalYesBet[market] / totalNoBet[market]);
                    msg.sender.call{value: payout}("");
                }
            }
        } else if (marketResolution[market] == 2) {
            for (uint256 i = 0; i < yesVotes[market].length; i++) {
                if (yesVotes[market][i].voter == msg.sender) {
                    uint256 payout = yesVotes[market][i].bet + (yesVotes[market][i].bet * totalNoBet[market] / totalYesBet[market]);
                    msg.sender.call{value: payout}("");
                }
            }
        }
    }

    function length() public view returns (uint256) {
        return nextMarketIndex;
    }

}
