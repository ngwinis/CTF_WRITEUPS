// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.13;

import { EdOnBN254 } from "solidity-ed-on-bn254/EdOnBN254V.sol";
import { DiceMarket } from "./DiceMarket.sol";
import { MerkleTree } from "./MerkleTree.sol";

interface IProposalVerifier {
    function verifyProof(
        uint256[2] calldata pA,
        uint256[2][2] calldata pB,
        uint256[2] calldata pC,
        uint256[2] calldata pubSignals
    ) external view returns (bool);
}

interface IVoteVerifier {
    function verifyProof(
        uint256[2] calldata pA,
        uint256[2][2] calldata pB,
        uint256[2] calldata pC,
        uint256[9] calldata pubSignals
    ) external view returns (bool);
}

interface ITallyVerifier {
    function verifyProof(
        uint256[2] calldata pA,
        uint256[2][2] calldata pB,
        uint256[2] calldata pC,
        uint256[8] calldata pubSignals
    ) external view returns (bool);
}

interface IProposalTarget {
    function executeProposal() external;
}

contract DiceMarketHolder {
    DiceMarket public market;

    constructor() payable {
        market = new DiceMarket{value: msg.value}();
    }
}

contract DiceMarketDAO is DiceMarketHolder, MerkleTree {
    struct Proof {
        uint256[2] pA;
        uint256[2][2] pB;
        uint256[2] pC;
    }

    struct EncryptedVote {
        uint256 voteNullifier;
        uint256 c1x;
        uint256 c1y;
        uint256 c2x;
        uint256 c2y;
    }

    struct Proposal {
        address codeAddress;
        uint256 votesCast;
        uint256 yesVotes;
        uint256 noVotes;
        bool finalized;
        bool accepted;
    }

    address public owner;

    IProposalVerifier public proposalVerifier;
    IVoteVerifier public voteVerifier;
    ITallyVerifier public tallyVerifier;

    uint256 public immutable tallyPubKeyX;
    uint256 public immutable tallyPubKeyY;

    uint256 public nextProposalIndex;

    mapping(uint256 => Proposal) public proposals;
    mapping(uint256 => EncryptedVote[]) private _proposalVotes;
    mapping(uint256 => bool) public usedVoteNullifiers;

    error InvalidProposal();
    error InvalidProof();
    error InvalidState();
    error InvalidInput();
    error VoteNullifierAlreadyUsed();
    error DelegatecallFailed();

    event VoterRegistered(uint256 indexed leaf, uint256 indexed index, uint256 root);
    event ProposalSubmitted(
        uint256 indexed proposalIndex,
        address indexed codeAddress
    );
    event VoteSubmitted(uint256 indexed proposalIndex, uint256 indexed voteNullifier);
    event ProposalTallied(uint256 indexed proposalIndex, uint256 yesVotes, uint256 noVotes, bool accepted);
    event ProposalExecuted(uint256 indexed proposalIndex, address indexed codeAddress);

    modifier onlyOwner() {
        require(msg.sender == owner);
        _;
    }

    constructor(
        IProposalVerifier _proposalVerifier,
        IVoteVerifier _voteVerifier,
        ITallyVerifier _tallyVerifier,
        uint256 _tallyPubKeyX,
        uint256 _tallyPubKeyY
    ) payable {
        owner = msg.sender;
        proposalVerifier = _proposalVerifier;
        voteVerifier = _voteVerifier;
        tallyVerifier = _tallyVerifier;
        tallyPubKeyX = _tallyPubKeyX;
        tallyPubKeyY = _tallyPubKeyY;
    }

    function registerVoter(uint256 voterLeaf) external onlyOwner returns (uint256 index) {
        index = _insert(voterLeaf);
        emit VoterRegistered(voterLeaf, index, root);
    }

    function propose(
        IProposalTarget codeAddress,
        uint256 proposalNullifierHash,
        Proof calldata proof
    ) external returns (uint256 proposalIndex) {
        uint256[2] memory pubSignals = [
            root,
            proposalNullifierHash
        ];

        bool ok = proposalVerifier.verifyProof(proof.pA, proof.pB, proof.pC, pubSignals);
        if (!ok) revert InvalidProof();

        proposalIndex = nextProposalIndex;
        nextProposalIndex += 1;

        Proposal storage p = proposals[proposalIndex];
        p.codeAddress = address(codeAddress);

        emit ProposalSubmitted(proposalIndex, address(codeAddress));
    }

    function vote(
        uint256 proposalIndex,
        uint256 voteNullifier,
        uint256 c1x,
        uint256 c1y,
        uint256 c2x,
        uint256 c2y,
        Proof calldata proof
    ) external {
        if (proposalIndex >= nextProposalIndex) revert InvalidProposal();
        if (usedVoteNullifiers[voteNullifier]) revert VoteNullifierAlreadyUsed();

        Proposal storage p = proposals[proposalIndex];
        if (p.finalized) revert InvalidState();
        if (p.votesCast >= length()) revert InvalidState();

        uint256[9] memory pubSignals = [
            root,
            voteNullifier,
            proposalIndex,
            tallyPubKeyX,
            tallyPubKeyY,
            c1x,
            c1y,
            c2x,
            c2y
        ];

        bool ok = voteVerifier.verifyProof(proof.pA, proof.pB, proof.pC, pubSignals);
        if (!ok) revert InvalidProof();

        usedVoteNullifiers[voteNullifier] = true;

        _proposalVotes[proposalIndex].push(
            EncryptedVote({
                voteNullifier: voteNullifier,
                c1x: c1x,
                c1y: c1y,
                c2x: c2x,
                c2y: c2y
            })
        );

        p.votesCast += 1;
        emit VoteSubmitted(proposalIndex, voteNullifier);
    }

    function finalizeProposal(uint256 proposalIndex, uint256 yesVotes, Proof calldata proof) external {
        if (proposalIndex >= nextProposalIndex) revert InvalidProposal();

        Proposal storage p = proposals[proposalIndex];
        if (p.finalized) revert InvalidState();

        (uint256 aggC1x, uint256 aggC1y, uint256 aggC2x, uint256 aggC2y) = _aggregateVotes(proposalIndex);

        uint256[8] memory pubSignals = [
            tallyPubKeyX,
            tallyPubKeyY,
            aggC1x,
            aggC1y,
            aggC2x,
            aggC2y,
            p.votesCast,
            yesVotes
        ];

        bool ok = tallyVerifier.verifyProof(proof.pA, proof.pB, proof.pC, pubSignals);
        if (!ok) revert InvalidProof();

        p.finalized = true;
        p.yesVotes = yesVotes;
        p.noVotes = length() - yesVotes;
        p.accepted = yesVotes > p.noVotes;

        emit ProposalTallied(proposalIndex, p.yesVotes, p.noVotes, p.accepted);

        if (p.accepted) {
            (bool success, ) = p.codeAddress.delegatecall(abi.encodeCall(IProposalTarget.executeProposal, ()));
            if (!success) revert DelegatecallFailed();
            emit ProposalExecuted(proposalIndex, p.codeAddress);
        }
    }

    function getProposalVotes(uint256 proposalIndex) external view returns (EncryptedVote[] memory) {
        if (proposalIndex >= nextProposalIndex) revert InvalidProposal();
        return _proposalVotes[proposalIndex];
    }

    function getProposalVoteCount(uint256 proposalIndex) external view returns (uint256) {
        if (proposalIndex >= nextProposalIndex) revert InvalidProposal();
        return _proposalVotes[proposalIndex].length;
    }

    function _aggregateVotes(uint256 proposalIndex) private view returns (uint256 aggC1x, uint256 aggC1y, uint256 aggC2x, uint256 aggC2y) {
        EncryptedVote[] storage votes = _proposalVotes[proposalIndex];
        EdOnBN254.Affine memory aggC1 = EdOnBN254.zero();
        EdOnBN254.Affine memory aggC2 = EdOnBN254.zero();

        for (uint256 i = 0; i < votes.length; i++) {
            aggC1 = EdOnBN254.add(
                aggC1,
                EdOnBN254.Affine({x: votes[i].c1x, y: votes[i].c1y})
            );
            aggC2 = EdOnBN254.add(
                aggC2,
                EdOnBN254.Affine({x: votes[i].c2x, y: votes[i].c2y})
            );
        }
        aggC1x = aggC1.x;
        aggC1y = aggC1.y;
        aggC2x = aggC2.x;
        aggC2y = aggC2.y;
    }
}
