// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.13;

import { PoseidonT3 } from "poseidon-solidity/PoseidonT3.sol";

contract MerkleTree {
    uint256 public constant DEPTH = 8;
    uint256 public constant MAX_LEAVES = uint256(1) << DEPTH;

    uint256 public root;
    uint256 public nextIndex;

    uint256[DEPTH] public filledSubtrees;

    constructor() {
        uint256 currentZero = 0;
        filledSubtrees[0] = 0;

        for (uint256 i = 1; i < DEPTH; i++) {
            currentZero = _hash(currentZero, currentZero);
            filledSubtrees[i] = currentZero;
        }

        root = _hash(currentZero, currentZero);
        nextIndex = 0;
    }

    function length() public view returns (uint256) {
        return nextIndex;
    }

    function _insert(uint256 leaf) internal returns (uint256 index) {
        if (nextIndex >= MAX_LEAVES) revert("the merkle tree is full");

        uint256 currentHash = leaf;
        uint256 currentIndex = nextIndex;
        uint256 currentZero = 0;
        index = currentIndex;

        for (uint256 level = 0; level < DEPTH; level++) {
            uint256 left;
            uint256 right;

            if (currentIndex % 2 == 0) {
                left = currentHash;
                right = currentZero;
                filledSubtrees[level] = currentHash;
            } else {
                left = filledSubtrees[level];
                right = currentHash;
            }

            currentHash = _hash(left, right);
            currentZero = _hash(currentZero, currentZero);
            currentIndex /= 2;
        }

        root = currentHash;
        nextIndex += 1;
    }

    function _hash(uint256 left, uint256 right) private pure returns (uint256) {
        uint256[2] memory inputs = [left, right];
        return PoseidonT3.hash(inputs);
    }
}
