pragma circom 2.2.3;

include "circomlib/circuits/poseidon.circom";
include "./MerkleTree.circom";

template Proposal(depth) {
    signal input votersRoot;
    signal input proposalNullifierHash;

    signal input voterNullifier;
    signal input voterSecret;
    signal input pathElements[depth];
    signal input pathIndices[depth];

    component leafHasher = Poseidon(2);
    leafHasher.inputs[0] <== voterNullifier;
    leafHasher.inputs[1] <== voterSecret;

    component merkleProof = MerkleTreeInclusionProof(depth);
    merkleProof.root <== votersRoot;
    merkleProof.leaf <== leafHasher.out;
    for (var i = 0; i < depth; i++) {
        merkleProof.pathElements[i] <== pathElements[i];
        merkleProof.pathIndices[i] <== pathIndices[i];
    }
}

component main { public [votersRoot, proposalNullifierHash] } = Proposal(8);
