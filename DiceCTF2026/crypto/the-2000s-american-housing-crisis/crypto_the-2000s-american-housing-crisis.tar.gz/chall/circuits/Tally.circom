pragma circom 2.2.3;

include "circomlib/circuits/bitify.circom";
include "circomlib/circuits/babyjub.circom";
include "circomlib/circuits/comparators.circom";
include "circomlib/circuits/escalarmulany.circom";

template Tally() {
    signal input tallyPubKeyX;
    signal input tallyPubKeyY;
    signal input aggC1x;
    signal input aggC1y;
    signal input aggC2x;
    signal input aggC2y;
    signal input numVotes;
    signal input yesVotes;

    signal input tallySecretKey;

    // https://eips.ethereum.org/EIPS/eip-2494#base-point
    var BASE8[2] = [
        5299619240641551281634865583518297030282874472190772894086521144482721001553,
        16950150798460657717958625567821834550301663161624707787222815936182638968203
    ];

    component skBits = Num2Bits(253);
    skBits.in <== tallySecretKey;

    component derivedPk = EscalarMulFix(253, BASE8);
    for (var i = 0; i < 253; i++) {
        derivedPk.e[i] <== skBits.out[i];
    }
    tallyPubKeyX === derivedPk.out[0];
    tallyPubKeyY === derivedPk.out[1];

    component sharedMul = EscalarMulAny(253);
    for (var j = 0; j < 253; j++) {
        sharedMul.e[j] <== skBits.out[j];
    }
    sharedMul.p[0] <== aggC1x;
    sharedMul.p[1] <== aggC1y;

    component msgAdder = BabyAdd();
    msgAdder.x1 <== aggC2x;
    msgAdder.y1 <== aggC2y;
    msgAdder.x2 <== -sharedMul.out[0];
    msgAdder.y2 <== sharedMul.out[1];

    component yesBits = Num2Bits(253);
    yesBits.in <== yesVotes;

    component yesMul = EscalarMulFix(253, BASE8);
    for (var k = 0; k < 253; k++) {
        yesMul.e[k] <== yesBits.out[k];
    }
    msgAdder.xout === yesMul.out[0];
    msgAdder.yout === yesMul.out[1];

    component yesLeqVotes = LessEqThan(9);
    yesLeqVotes.in[0] <== yesVotes;
    yesLeqVotes.in[1] <== numVotes;
    yesLeqVotes.out === 1;

    component votesLeqMax = LessEqThan(9);
    votesLeqMax.in[0] <== numVotes;
    votesLeqMax.in[1] <== 256;
    votesLeqMax.out === 1;
}

component main { public [tallyPubKeyX, tallyPubKeyY, aggC1x, aggC1y, aggC2x, aggC2y, numVotes, yesVotes] } = Tally();
