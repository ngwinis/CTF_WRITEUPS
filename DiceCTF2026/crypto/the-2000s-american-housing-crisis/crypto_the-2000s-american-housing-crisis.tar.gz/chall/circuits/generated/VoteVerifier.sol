// SPDX-License-Identifier: GPL-3.0
/*
    Copyright 2021 0KIMS association.

    This file is generated with [snarkJS](https://github.com/iden3/snarkjs).

    snarkJS is a free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    snarkJS is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
    or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public
    License for more details.

    You should have received a copy of the GNU General Public License
    along with snarkJS. If not, see <https://www.gnu.org/licenses/>.
*/

pragma solidity >=0.7.0 <0.9.0;

contract VoteVerifier {
    // Scalar field size
    uint256 constant r    = 21888242871839275222246405745257275088548364400416034343698204186575808495617;
    // Base field size
    uint256 constant q   = 21888242871839275222246405745257275088696311157297823662689037894645226208583;

    // Verification Key data
    uint256 constant alphax  = 7867131396724038513297486103137909919293580759315000695739155796888847122407;
    uint256 constant alphay  = 12728580098728299118725810411235008895413910792868977743576832399247556988024;
    uint256 constant betax1  = 16283789952553526617954289817706426448738319478059682039694227870953687214760;
    uint256 constant betax2  = 813656521377873073859230672844538071516444956732860548918879648455507026165;
    uint256 constant betay1  = 9758045670508340059662374043185474608149489648199761323751621613267264208515;
    uint256 constant betay2  = 7624743689813545690463606464500259876403222153748451719757834039780413672571;
    uint256 constant gammax1 = 11559732032986387107991004021392285783925812861821192530917403151452391805634;
    uint256 constant gammax2 = 10857046999023057135944570762232829481370756359578518086990519993285655852781;
    uint256 constant gammay1 = 4082367875863433681332203403145435568316851327593401208105741076214120093531;
    uint256 constant gammay2 = 8495653923123431417604973247489272438418190587263600148770280649306958101930;
    uint256 constant deltax1 = 12681266375194875912983841016674786324693897272089295514506615715396819689512;
    uint256 constant deltax2 = 21476022792113836129413995138059436459092686037649749105887313330520643455764;
    uint256 constant deltay1 = 15631098632684480601855002310879436240011450088085280158067962113686476065216;
    uint256 constant deltay2 = 21830738685410940169117112809004273000736445815650091674109742069443712303290;

    
    uint256 constant IC0x = 9118971545096154092455270429154336160600567746881246344768414205597484729550;
    uint256 constant IC0y = 11868115328495804410921318838575550734949253667557964709136834134800746819280;
    
    uint256 constant IC1x = 2908114293340595534351032287900032811678913053495773418188910296859244154641;
    uint256 constant IC1y = 21432376017196509401913047789154026475179141125065105588687772145653911804069;
    
    uint256 constant IC2x = 11095416238802991888273723337041156775044288293478955296680619717624165598903;
    uint256 constant IC2y = 11268812866349733063723241961898735700154527070130783394091739006204720104945;
    
    uint256 constant IC3x = 19448466037823088549021244420019853507421864801662263493382811438894741025686;
    uint256 constant IC3y = 6380402936042561378580163816435279177503136512095490702701222475861535888610;
    
    uint256 constant IC4x = 15642727041269924615251641900436278478590284557462377125568634285277641268725;
    uint256 constant IC4y = 18298209467139891574714512766885122456775246330667605332032718226196747239399;
    
    uint256 constant IC5x = 16527148562756145082365931318590244170463557329098673415886423963915622353753;
    uint256 constant IC5y = 13985093879479272932878411760813127512560868652105144322924009599340561981860;
    
    uint256 constant IC6x = 11982879468664923196370832327146681785507396334753745437535637960885630600768;
    uint256 constant IC6y = 9470060325137165815793253171239609728229666070686210290235122955835473680683;
    
    uint256 constant IC7x = 18292296059006686546696297564563325475028973535113855645197861899506720230907;
    uint256 constant IC7y = 18569001857267172912346905153956771340433594897034642921078763203152671324531;
    
    uint256 constant IC8x = 11460048263811004491544656909179364628313332908384603607119598601884859989167;
    uint256 constant IC8y = 2042243507931223320216595111738857860406048642596790497387730221069650770081;
    
    uint256 constant IC9x = 1085641587154502439088700672226559100274860955398551688549431416886141294392;
    uint256 constant IC9y = 2033000333565446565649279730374475077260386511867664201824160614954934693770;
    
 
    // Memory data
    uint16 constant pVk = 0;
    uint16 constant pPairing = 128;

    uint16 constant pLastMem = 896;

    function verifyProof(uint[2] calldata _pA, uint[2][2] calldata _pB, uint[2] calldata _pC, uint[9] calldata _pubSignals) public view returns (bool) {
        assembly {
            function checkField(v) {
                if iszero(lt(v, r)) {
                    mstore(0, 0)
                    return(0, 0x20)
                }
            }
            
            // G1 function to multiply a G1 value(x,y) to value in an address
            function g1_mulAccC(pR, x, y, s) {
                let success
                let mIn := mload(0x40)
                mstore(mIn, x)
                mstore(add(mIn, 32), y)
                mstore(add(mIn, 64), s)

                success := staticcall(sub(gas(), 2000), 7, mIn, 96, mIn, 64)

                if iszero(success) {
                    mstore(0, 0)
                    return(0, 0x20)
                }

                mstore(add(mIn, 64), mload(pR))
                mstore(add(mIn, 96), mload(add(pR, 32)))

                success := staticcall(sub(gas(), 2000), 6, mIn, 128, pR, 64)

                if iszero(success) {
                    mstore(0, 0)
                    return(0, 0x20)
                }
            }

            function checkPairing(pA, pB, pC, pubSignals, pMem) -> isOk {
                let _pPairing := add(pMem, pPairing)
                let _pVk := add(pMem, pVk)

                mstore(_pVk, IC0x)
                mstore(add(_pVk, 32), IC0y)

                // Compute the linear combination vk_x
                
                g1_mulAccC(_pVk, IC1x, IC1y, calldataload(add(pubSignals, 0)))
                
                g1_mulAccC(_pVk, IC2x, IC2y, calldataload(add(pubSignals, 32)))
                
                g1_mulAccC(_pVk, IC3x, IC3y, calldataload(add(pubSignals, 64)))
                
                g1_mulAccC(_pVk, IC4x, IC4y, calldataload(add(pubSignals, 96)))
                
                g1_mulAccC(_pVk, IC5x, IC5y, calldataload(add(pubSignals, 128)))
                
                g1_mulAccC(_pVk, IC6x, IC6y, calldataload(add(pubSignals, 160)))
                
                g1_mulAccC(_pVk, IC7x, IC7y, calldataload(add(pubSignals, 192)))
                
                g1_mulAccC(_pVk, IC8x, IC8y, calldataload(add(pubSignals, 224)))
                
                g1_mulAccC(_pVk, IC9x, IC9y, calldataload(add(pubSignals, 256)))
                

                // -A
                mstore(_pPairing, calldataload(pA))
                mstore(add(_pPairing, 32), mod(sub(q, calldataload(add(pA, 32))), q))

                // B
                mstore(add(_pPairing, 64), calldataload(pB))
                mstore(add(_pPairing, 96), calldataload(add(pB, 32)))
                mstore(add(_pPairing, 128), calldataload(add(pB, 64)))
                mstore(add(_pPairing, 160), calldataload(add(pB, 96)))

                // alpha1
                mstore(add(_pPairing, 192), alphax)
                mstore(add(_pPairing, 224), alphay)

                // beta2
                mstore(add(_pPairing, 256), betax1)
                mstore(add(_pPairing, 288), betax2)
                mstore(add(_pPairing, 320), betay1)
                mstore(add(_pPairing, 352), betay2)

                // vk_x
                mstore(add(_pPairing, 384), mload(add(pMem, pVk)))
                mstore(add(_pPairing, 416), mload(add(pMem, add(pVk, 32))))


                // gamma2
                mstore(add(_pPairing, 448), gammax1)
                mstore(add(_pPairing, 480), gammax2)
                mstore(add(_pPairing, 512), gammay1)
                mstore(add(_pPairing, 544), gammay2)

                // C
                mstore(add(_pPairing, 576), calldataload(pC))
                mstore(add(_pPairing, 608), calldataload(add(pC, 32)))

                // delta2
                mstore(add(_pPairing, 640), deltax1)
                mstore(add(_pPairing, 672), deltax2)
                mstore(add(_pPairing, 704), deltay1)
                mstore(add(_pPairing, 736), deltay2)


                let success := staticcall(sub(gas(), 2000), 8, _pPairing, 768, _pPairing, 0x20)

                isOk := and(success, mload(_pPairing))
            }

            let pMem := mload(0x40)
            mstore(0x40, add(pMem, pLastMem))

            // Validate that all evaluations ∈ F
            
            checkField(calldataload(add(_pubSignals, 0)))
            
            checkField(calldataload(add(_pubSignals, 32)))
            
            checkField(calldataload(add(_pubSignals, 64)))
            
            checkField(calldataload(add(_pubSignals, 96)))
            
            checkField(calldataload(add(_pubSignals, 128)))
            
            checkField(calldataload(add(_pubSignals, 160)))
            
            checkField(calldataload(add(_pubSignals, 192)))
            
            checkField(calldataload(add(_pubSignals, 224)))
            
            checkField(calldataload(add(_pubSignals, 256)))
            

            // Validate all evaluations
            let isValid := checkPairing(_pA, _pB, _pC, _pubSignals, pMem)

            mstore(0, isValid)
             return(0, 0x20)
         }
     }
 }
