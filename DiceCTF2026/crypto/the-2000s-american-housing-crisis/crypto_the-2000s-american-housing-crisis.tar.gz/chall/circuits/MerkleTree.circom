pragma circom 2.2.3;

include "circomlib/circuits/poseidon.circom";

template MerkleTreeInclusionProof(depth) {
    signal input root;
    signal input leaf;
    signal input pathElements[depth];
    signal input pathIndices[depth];

    signal output computedRoot;

    signal hashes[depth + 1];
    signal leftNodes[depth];
    signal rightNodes[depth];
    component levelHashers[depth];

    hashes[0] <== leaf;

    for (var i = 0; i < depth; i++) {
        pathIndices[i] * (1 - pathIndices[i]) === 0;

        leftNodes[i] <== hashes[i] + pathIndices[i] * (pathElements[i] - hashes[i]);
        rightNodes[i] <== pathElements[i] + pathIndices[i] * (hashes[i] - pathElements[i]);

        levelHashers[i] = Poseidon(2);
        levelHashers[i].inputs[0] <== leftNodes[i];
        levelHashers[i].inputs[1] <== rightNodes[i];

        hashes[i + 1] <== levelHashers[i].out;
    }

    computedRoot <== hashes[depth];
    computedRoot === root;
}
