pragma circom 2.2.3;

include "circomlib/circuits/poseidon.circom";
include "circomlib/circuits/bitify.circom";
include "circomlib/circuits/babyjub.circom";
include "circomlib/circuits/escalarmulany.circom";
include "./MerkleTree.circom";

template Vote(depth) {
    signal input votersRoot;
    signal input voteNullifier;
    signal input proposal;
    signal input tallyPubKeyX;
    signal input tallyPubKeyY;
    signal input c1x;
    signal input c1y;
    signal input c2x;
    signal input c2y;

    signal input voterNullifier;
    signal input voterSecret;
    signal input voteBit;
    signal input voteRandomness;
    signal input pathElements[depth];
    signal input pathIndices[depth];

    // https://eips.ethereum.org/EIPS/eip-2494#base-point
    var BASE8[2] = [
        5299619240641551281634865583518297030282874472190772894086521144482721001553,
        16950150798460657717958625567821834550301663161624707787222815936182638968203
    ];

    voteBit * (1 - voteBit) === 0;

    component pkCheck = BabyCheck();
    pkCheck.x <== tallyPubKeyX;
    pkCheck.y <== tallyPubKeyY;

    component leafHasher = Poseidon(2);
    leafHasher.inputs[0] <== voterNullifier;
    leafHasher.inputs[1] <== voterSecret;

    component merkleProof = MerkleTreeInclusionProof(depth);
    merkleProof.root <== votersRoot;
    merkleProof.leaf <== leafHasher.out;
    for (var i = 0; i < depth; i++) {
        merkleProof.pathElements[i] <== pathElements[i];
        merkleProof.pathIndices[i] <== pathIndices[i];
    }

    component nullifierHasher = Poseidon(2);
    nullifierHasher.inputs[0] <== voterNullifier;
    nullifierHasher.inputs[1] <== proposal;
    voteNullifier === nullifierHasher.out;

    component rBits = Num2Bits(253);
    rBits.in <== voteRandomness;

    component rMulBase = EscalarMulFix(253, BASE8);
    for (var j = 0; j < 253; j++) {
        rMulBase.e[j] <== rBits.out[j];
    }
    c1x === rMulBase.out[0];
    c1y === rMulBase.out[1];

    component rMulPk = EscalarMulAny(253);
    for (var k = 0; k < 253; k++) {
        rMulPk.e[k] <== rBits.out[k];
    }
    rMulPk.p[0] <== tallyPubKeyX;
    rMulPk.p[1] <== tallyPubKeyY;

    signal msgX;
    signal msgY;
    msgX <== voteBit * BASE8[0];
    msgY <== 1 + voteBit * (BASE8[1] - 1);

    component c2Adder = BabyAdd();
    c2Adder.x1 <== rMulPk.out[0];
    c2Adder.y1 <== rMulPk.out[1];
    c2Adder.x2 <== msgX;
    c2Adder.y2 <== msgY;
    c2x === c2Adder.xout;
    c2y === c2Adder.yout;
}

component main { public [votersRoot, voteNullifier, proposal, tallyPubKeyX, tallyPubKeyY, c1x, c1y, c2x, c2y] } = Vote(8);
